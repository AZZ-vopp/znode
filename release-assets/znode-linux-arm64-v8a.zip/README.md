# ZNode

ZNode là agent dành cho [AZZ-vopp/zboard](https://github.com/AZZ-vopp/zboard),
hỗ trợ chạy nhiều logical node trên một VPS và giới hạn thiết bị phân tán qua
Redis.

## Tính năng

- Một agent quản lý nhiều logical node trên cùng VPS.
- Từ chối node trùng port trước khi áp dụng cấu hình.
- Giới hạn IP/HWID/UUID thiết bị qua Redis.
- Pub/Sub đồng bộ thay đổi thiết bị gần như tức thời.
- Chia sẻ Redis connection pool giữa các logical node.
- Tối ưu bộ đếm traffic và UDP để giảm CPU/RAM.
- Gửi CPU, RAM, disk và tốc độ mạng về ZBoard.
- TLS tự ký và SHA-256 certificate pinning.
- Last-known-good offline runtime: panel mất kết nối hoặc ZNode khởi động lại
  trong lúc web sập vẫn giữ node và user cuối cùng hoạt động.
- Chỉ kết nối với ZBoard bằng nhận diện hai chiều, không chạy với V2Board gốc.

Xem thêm [tài liệu Redis và tối ưu UDP](docs/ZNODE_REDIS_UDP_VI.md).

## Cài đặt

Khuyến nghị tạo Agent/VPS trong ZBoard rồi sử dụng đúng lệnh cài đặt được sinh
trên màn hình Admin. Cài thủ công installer:

```bash
wget -N https://raw.githubusercontent.com/AZZ-vopp/znode/main/script/install.sh
bash install.sh
```

Cài agent bằng thông tin do ZBoard cấp. Token được đọc qua stdin để không xuất
hiện trong shell history hoặc danh sách process:

```bash
read -rsp 'Agent token: ' ZNODE_AGENT_TOKEN; echo
printf '%s\n' "$ZNODE_AGENT_TOKEN" | bash install.sh \
  --api-host https://panel.example.com \
  --agent-id AGENT_ID \
  --agent-token-stdin \
  --release-repo AZZ-vopp/znode \
  --release-branch main
unset ZNODE_AGENT_TOKEN
```

Installer lưu repository phát hành trong `/etc/znode/release-repo`; lệnh
`znode update` sau này tiếp tục tải đúng binary từ `AZZ-vopp/znode`.
Installer chỉ chấp nhận gói có tệp `.dgst`, kiểm tra SHA-256 trước khi giải nén
và tải script qua HTTPS có kiểm tra chứng chỉ. Bản trước được giữ tại
`/usr/local/znode.rollback` để có thể khôi phục nếu cần; không tắt kiểm tra TLS
hoặc tự thay URL tải bằng nguồn không tin cậy.

## Biên dịch

Yêu cầu Go 1.27.1. `encoding/json/v2` đã ổn định từ Go 1.27:

```bash
./script/with-xray-core.sh go test ./...
./script/with-xray-core.sh go build -v -o build_assets/znode \
  -trimpath \
  -ldflags "-X 'github.com/AZZ-vopp/znode/cmd.version=dev' -s -w -buildid="
```

Wrapper trên dùng cùng nhánh lõi với v2node hiện tại: fork
`github.com/wyx2685/xray-core` tại snapshot
`v0.0.0-20260828071630-83ad74c46335`, có AnyTLS/TUIC. Sau đó wrapper áp các
backport đã kiểm tra trong `patches/xray-core` vào bản sao tạm. Module cache gốc
không bị sửa; patch đã có sẵn trong snapshot sẽ được bỏ qua, còn patch không
tương thích sẽ làm build dừng ngay.

## Relay UDP PROXY v2

Với Hysteria2 hoặc TUIC qua relay SNAT, chạy relay tích hợp để gửi PROXY v2 UDP
trên từng datagram:

```bash
znode udp-relay --network udp4 --listen :443 --upstream ZNODE_IPV4:443 --ttl 2m --max-flows 512
```

Bật `acceptProxyProtocol: true` và nhập `proxyProtocolTrustedIPs` (IP/CIDR
relay, không wildcard) ở node UDP trên ZBoard sau khi relay và ZNode đã nâng
cấp. Cổng backend vẫn phải firewall cho relay; khi bật, ZNode loại raw UDP,
header không hợp lệ và peer không thuộc allow-list. Chạy service `udp4` và
`udp6` riêng nếu cần cả hai family. Xem `web/docs/DEPLOYMENT_VI.md` trong
workspace để có thứ tự rollout và ví dụ systemd/LimitNOFILE.

## Relay TCP PROXY v1 qua IPv6 → IPv4

Với Shadowsocks hoặc inbound TCP khác đi qua relay nhận IPv6 rồi chuyển tới
ZNode IPv4, relay phải chèn PROXY v1 trước dữ liệu giao thức. ZNode chấp nhận
dạng `PROXY TCP6 <client-ipv6> <backend-ipv4> <client-port> <server-port>` và
chuyển địa chỉ client IPv6 cho giới hạn thiết bị. Nếu chỉ DNAT/port-forward mà
không chèn header, không bật `acceptProxyProtocol`; header là bắt buộc và kết
nối sẽ bị loại trước khi Shadowsocks đọc payload mã hoá. Cổng backend chỉ nên
cho phép IP relay truy cập.

## Phát hành

GitHub Actions build binary theo kiến trúc khi push mã Go lên nhánh `main` hoặc
khi tạo Release. Để installer hoạt động, repository cần có ít nhất một GitHub
Release chứa các tệp `znode-linux-<arch>.zip` do workflow tạo ra.

## Cấu hình Redis

ZBoard và ZNode phải dùng cùng Redis nếu bật đồng bộ thiết bị thời gian thực.
Giữ cùng channel đã cấu hình trên panel, mặc định `v2board:device-sync`.

Thông tin Agent được lưu tại `/etc/znode/config.json` với quyền `0600`. Không
chia sẻ Agent token hoặc sao chép file này sang VPS khác.
Mọi cấu hình hợp lệ phải có trường `"type": "zboard"` ở cấp cao nhất.

Sau lần khởi động online thành công, ZNode ghi snapshot nguyên tử tại
`/var/lib/znode/runtime.snapshot`. File có quyền `0600`, được xác thực HMAC bằng
Agent token và chỉ được dùng khi API ZBoard không truy cập được. Snapshot không
có thời hạn tự hết hiệu lực để VPS tiếp tục phục vụ trong sự cố dài; khi panel
trở lại, các task tự đồng bộ cấu hình, user và traffic đang chờ. Chỉ phản hồi
thu hồi Agent có marker riêng từ ứng dụng ZBoard mới được phép gỡ các inbound;
trang lỗi `401/403` chung từ CDN/WAF không làm node dừng.

Traffic protocol 2 phân biệt `409 traffic_report_processing` (tiếp tục giữ và
retry cùng batch) với `409 traffic_report_payload_changed` (xung đột payload cần
operator kiểm tra). Khi một kết nối Hysteria kết thúc vì QUIC idle timeout,
ZNode ghi thêm IP khách, RTT, packet loss và byte counters để phân biệt mất
đường UDP thật với lỗi định tuyến WireGuard ở tầng sau.

## Giấy phép

Xem [LICENSE](LICENSE). Dự án sử dụng Xray core đã tùy chỉnh theo khai báo trong
`go.mod`.

## Dữ liệu GeoIP và GeoSite

Các rule Xray dùng `geoip:` và `geosite:` cần đồng thời hai file
`geoip.dat` và `geosite.dat`. Bản phát hành tự tải dữ liệu mới nhất từ
Loyalsoldier, trình cài đặt xác thực file không rỗng rồi đặt chúng tại
`/etc/znode`. Znode tự đặt `XRAY_LOCATION_ASSET` về thư mục chứa đủ hai file;
Docker image cũng đóng gói sẵn dữ liệu vào `/etc/znode`.

Khi chạy Docker, phải gắn volume bền vững vào `/var/lib/znode`, ví dụ
`-v znode-data:/var/lib/znode`. Đây là nơi lưu batch traffic chưa được ZBoard
xác nhận; không mount thư mục này sẽ làm mất batch đang chờ khi thay container.

Có thể đổi nguồn tải khi cài bằng biến `ZNODE_GEODATA_URL`, ví dụ một mirror
nội bộ có cấu trúc `.../geoip.dat` và `.../geosite.dat`.
