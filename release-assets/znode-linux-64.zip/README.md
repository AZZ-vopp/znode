# ZNode

ZNode là agent dành cho [AZZ-vopp/zboard](https://github.com/AZZ-vopp/zboard),
hỗ trợ chạy nhiều logical node trên một VPS và giới hạn thiết bị phân tán qua
Redis.

## Tính năng

- Một agent quản lý nhiều logical node trên cùng VPS.
- Từ chối node trùng port trước khi áp dụng cấu hình.
- Giới hạn IP/HWID/UUID thiết bị qua Redis.
- Pub/Sub đồng bộ thay đổi thiết bị gần như tức thời.
- Chia sẻ Redis connection pool giữa các logical node.
- Tối ưu bộ đếm traffic và UDP để giảm CPU/RAM.
- Chặn toàn cục `tiktokmod.pro`, `amemv.com`, `9mod.com`, `tiktok.tps.dv.tech` và
  `update.9mod.com` (gồm subdomain) bằng route-only sniffing HTTP/TLS/QUIC; không
  nhận diện được ECH hoặc kết nối chỉ dùng địa chỉ IP. Cấu hình cũ yêu cầu tắt
  UDP/QUIC sniffing sẽ được ghi cảnh báo và giữ sniffing bật để áp dụng luật.
- Gửi CPU, RAM, disk và tốc độ mạng về ZBoard.
- TLS tự ký và SHA-256 certificate pinning.
- Last-known-good offline runtime: panel mất kết nối hoặc ZNode khởi động lại
  trong lúc web sập vẫn giữ node và user cuối cùng hoạt động.
- Chỉ kết nối với ZBoard bằng nhận diện hai chiều, không chạy với V2Board gốc.

Xem thêm [tài liệu Redis và tối ưu UDP](docs/ZNODE_REDIS_UDP_VI.md).

## Cài đặt

Khuyến nghị tạo Agent/VPS trong ZBoard rồi sử dụng đúng lệnh cài đặt được sinh
trên màn hình Admin. Cài thủ công installer:

```bash
wget -N https://raw.githubusercontent.com/AZZ-vopp/znode/main/script/install.sh
bash install.sh
```

Cài agent bằng thông tin do ZBoard cấp. Token được đọc qua stdin để không xuất
hiện trong shell history hoặc danh sách process:

```bash
read -rsp 'Agent token: ' ZNODE_AGENT_TOKEN; echo
printf '%s\n' "$ZNODE_AGENT_TOKEN" | bash install.sh \
  --api-host https://panel.example.com \
  --agent-id AGENT_ID \
  --agent-token-stdin \
  --release-repo AZZ-vopp/znode \
  --release-branch main
unset ZNODE_AGENT_TOKEN
```

Installer lưu repository phát hành trong `/etc/znode/release-repo`; lệnh
`znode update` sau này tiếp tục tải đúng binary từ `AZZ-vopp/znode`.
Installer chỉ chấp nhận gói có tệp `.dgst`, kiểm tra SHA-256 trước khi giải nén
và tải script qua HTTPS có kiểm tra chứng chỉ. Bản trước được giữ tại
`/usr/local/znode.rollback` để có thể khôi phục nếu cần; không tắt kiểm tra TLS
hoặc tự thay URL tải bằng nguồn không tin cậy.

## Buffer UDP của kernel

Linux cấp cho mỗi socket UDP buffer nhận mặc định `net.core.rmem_default`
(208 KiB). Một đợt tải video QUIC hoặc một khách Hysteria2 bận là đủ làm đầy
buffer đó trong vài mili giây; kernel lặng lẽ vứt gói (`UdpRcvbufErrors` tăng
trong `nstat -az`) và khách thấy phiên "mất ping" vài giây rồi tự có lại.

Runtime tự yêu cầu 4 MiB cho mọi socket UDP nó mở (listener Hysteria2/TUIC/
Shadowsocks và socket outbound freedom) qua `SO_RCVBUF`/`SO_SNDBUF`. Kernel giới
hạn yêu cầu đó ở `net.core.rmem_max`/`wmem_max`, nên installer ghi
`/etc/sysctl.d/99-znode-udp.conf` nâng trần và giá trị mặc định (chỉ nâng, không
hạ giá trị operator đã đặt cao hơn) rồi áp ngay bằng `sysctl -p`. Kiểm tra sau
khi cài hoặc cập nhật:

```bash
sysctl net.core.rmem_default net.core.rmem_max
nstat -n; sleep 60; nstat UdpRcvbufErrors   # mong đợi gần 0 drop/phút
```

Node nâng cấp từ bản cũ cần `systemctl restart znode` một lần để listener đang
mở nhận buffer mới; socket outbound tự nhận khi được tạo lại.

## Biên dịch

Yêu cầu Go 1.27.2. `encoding/json/v2` đã ổn định từ Go 1.27:

```bash
./script/with-xray-core.sh go test ./...
./script/with-xray-core.sh go build -v -o build_assets/znode \
  -trimpath \
  -ldflags "-X 'github.com/AZZ-vopp/znode/cmd.version=dev' -s -w -buildid="
```

Wrapper trên dùng cùng nhánh lõi với v2node hiện tại: fork
`github.com/wyx2685/xray-core` tại snapshot
`v0.0.0-20260930151924-e087e74a1bf2`, có AnyTLS/TUIC. Sau đó wrapper áp các
backport đã kiểm tra trong `patches/xray-core` vào bản sao tạm. Module cache gốc
không bị sửa. Wrapper cũng áp patch tương thích REALITY trong `patches/reality`
vào bản sao tạm của dependency đã ghim, giữ khả năng kết nối X25519 cũ của
V2Node cùng với client hỗ trợ khóa lai mới. Patch đã có sẵn sẽ được bỏ qua, còn
patch không tương thích sẽ làm build dừng ngay.

## Admission REALITY trước xác thực

Mỗi kết nối TCP tới inbound REALITY phải đi qua handshake trước khi được xác
thực; trong lúc đó ZNode dial đích giả trang và giữ một slot trong pool toàn
tiến trình, dùng chung cho mọi logical node trên host. Client không bật mux mở
một handshake cho mỗi kết nối TCP, nên cơn bão reconnect sau một lần mất mạng
ngắn dễ vượt pool cũ 128 slot; socket dư khi đó bị reset im lặng và người dùng
thấy "mất mạng đột ngột" dù node vẫn chạy. Patch
`patches/xray-core/zzzzz-reality-admission-capacity.patch` đổi hành vi này:

- Pool 1024 slot handshake đang chờ xác thực (trước đây 128).
- Socket đến khi pool đầy chờ tối đa 2 giây để nhận slot theo thứ tự đến, thay
  vì bị đóng ngay; hàng chờ tối đa 4096 socket, quá ngưỡng mới đóng tức thì.
- Khi vẫn phải đóng, ZNode ghi cảnh báo `REALITY pre-auth admission ...` kèm
  tổng số socket đã đóng, tối đa 10 giây một dòng. Trước đây không có log.

Kiểm tra trên node: `journalctl -u znode --since -1h | grep -c "REALITY pre-auth
admission"`; con số tăng nghĩa là node đang bị quét hoặc bão reconnect vượt cả
pool mới, cần xem `REALITY: processed invalid connection` để phân biệt scanner
với client hợp lệ. Thời gian chờ handshake 15 giây cho dial đích và ClientHello
không đổi.

## Không giới hạn số phiên (giống v2node)

ZNode không còn giới hạn số phiên mỗi tài khoản hay toàn node. Trước đây trần
mặc định 512 phiên mỗi UUID (tính cả association UDP giữ tới hết `ConnIdle`
300 giây) làm khách xem video hoặc dùng nhiều luồng QUIC bị rớt giữa chừng:
VLESS bị từ chối kết nối mới, còn Hysteria2 bị bỏ datagram không báo lỗi.

Các khoá `MaxConnectionsPerUser` và `MaxConnections` trong `ConnectionConfig`
của `/etc/znode/config.json` vẫn được đọc để file cũ không lỗi nhưng bị bỏ qua.
Bộ cài mới không ghi hai khoá này. Giới hạn thiết bị/IP của panel và
`LimitNOFILE=262144` của systemd vẫn áp dụng.

## WireGuard `domainStrategy` (giống v2node)

Từ v1.37.87, `settings.domainStrategy` trong outbound WireGuard được áp dụng
thật: ZNode chuyển nó thành `targetStrategy` của outbound để Xray phân giải tên
miền đích bằng DNS của node trước khi vào tunnel (trước đây giá trị bị bỏ qua
và tên miền được phân giải qua `remoteDNS` trong tunnel, gây lỗi
`lookup ... on 1.0.0.1: i/o timeout`). Bỏ trống thì mặc định `ForceIPv4`; nhận
`AsIs`, `UseIP`, `UseIPv4`, `UseIPv4v6`, `ForceIP`, `ForceIPv4`, `ForceIPv4v6`.
Giá trị ưu tiên IPv6 bị từ chối vì tunnel chỉ có IPv4.

## Đồng bộ người dùng bền hơn

Từ v1.37.88:

- Xoá một người dùng bị lỗi (drain/RemoveUser hết hạn) không còn chặn việc
  thêm người mới; người dùng được thêm từng người, một người bị Xray từ chối
  chỉ bị bỏ qua và thử lại ở lượt sau.
- Danh sách từ panel có dòng hỏng hoặc UUID trùng: bỏ dòng đó (giữ dòng đầu),
  vẫn áp dụng phần còn lại thay vì giữ nguyên danh sách cũ.
- Snapshot Redis dùng khi panel mất kết nối chỉ được **thêm** người dùng, không
  xoá hay sửa người đang có; revision chưa được đánh dấu đã xử lý cho tới khi
  panel trả danh sách thật.
- Đổi report ID của cùng một UUID được cập nhật tại chỗ, không ngắt phiên.
- Gia hạn chứng chỉ ACME dùng lại private key hiện có.
- Từ v1.37.89: một người dùng bị Xray từ chối cũng không còn làm inbound
  không khởi động được khi restart/reload; người đó bị bỏ qua và thử lại sau.
- Từ v1.37.90: người dùng mới/được thay đổi được thêm **trước** khi xoá người
  hết hạn, nên một loạt xoá chậm (mỗi người tối đa 5 giây drain) không còn làm
  hết hạn lượt đồng bộ trước khi kịp thêm người vừa gia hạn hoặc mua mới.
- Từ v1.37.90: người dùng bị xoá dở (drain chưa xong) mà panel liệt kê lại (gia
  hạn ngay) được huỷ lệnh xoá và cho kết nối lại, thay vì bị chặn trên node đó
  cho tới khi drain thành công.

## Giới hạn tốc độ

Từ v1.37.90, giới hạn tốc độ của mỗi người dùng tách riêng chiều tải lên và
tải xuống, nạp token liên tục thay vì mỗi giây một lần, và mỗi lần ghi chỉ giữ
chỗ tối đa 16 KiB. Trước đây một luồng tải nặng làm kết nối mới của cùng người
dùng (bắt tay TLS/REALITY, ping) phải chờ vài giây sau phần nợ token, trông
như timeout trên gói có giới hạn tốc độ.

## Một node chạy trên nhiều VPS

Node có nhiều instance Agent (`load_agent_ips`) chỉ công bố một mã pin
chứng chỉ cho khách hàng. Trước v1.37.91 mỗi VPS giữ chứng chỉ tự ký riêng và
lượt `sync` vault đẩy chứng chỉ cục bộ lên, nên vault và mã pin bị các VPS
thay nhau ghi đè: khách chỉ kết nối được VPS trùng pin, còn lại báo lỗi TLS
hoặc timeout.

Từ v1.37.91, khi panel gửi `adopt_vault` (chỉ với `cert_mode` `self`, `auto`,
`dns`, `http` và vault đã có chứng chỉ) mà chứng chỉ cục bộ là tự ký và khác
vault, ZNode tải cặp chứng chỉ từ vault, kiểm tra SHA-256 khớp
`expected_sha256`, đổi tên cặp cũ thành `*.replaced-<thời gian>` rồi ghi cặp
mới nguyên tử và nạp lại runtime. Mọi VPS khi đó phục vụ cùng chứng chỉ đã
pin. Chứng chỉ do CA cấp (ACME gia hạn) vẫn được đẩy lên vault như trước. Nếu
tải vault thất bại, ZNode giữ nguyên cặp cục bộ và không đẩy đè vault; lượt
manifest sau sẽ thử lại. Panel cũ không gửi cờ này nên ZNode giữ hành vi cũ;
cần cập nhật Web trước rồi mới cập nhật ZNode.

Từ v1.37.92, lỗi khi đẩy cặp chứng chỉ đang chạy lên vault (VPS anh em đã
dùng nonce, panel từ chối, cặp cục bộ không đọc được) chỉ ghi cảnh báo và bỏ
qua node đó. Trước đây lỗi này làm Agent bỏ qua toàn bộ manifest: node mới,
đổi cổng/SNI, fallback không được áp dụng và mọi lần reload đều thất bại. Lỗi
khôi phục khi VPS chưa có chứng chỉ vẫn dừng lại như cũ, để không tự sinh
chứng chỉ mới làm sai mã pin.

## Reload không phụ thuộc danh sách thiết bị online

Từ v1.37.92, nếu panel không trả được `alivelist` khi chuẩn bị reload, ZNode
vẫn reload với số thiết bị trống (đợt đồng bộ định kỳ nạp lại) thay vì làm
thất bại reload của mọi node. Controller đang chạy giữ số đếm cũ.

## Reload tại chỗ khi còn lệnh xoá người dùng dở dang

Từ v1.37.92, một lệnh xoá người dùng chưa drain xong không còn biến mọi thay
đổi trên panel thành restart toàn bộ Xray. Inbound không đổi giữ nguyên
controller cùng lệnh xoá đang chờ (đợt đồng bộ định kỳ tiếp tục thử); inbound
bị thay thế loại người dùng đó khỏi danh sách của inbound mới. Người dùng đã
bị thu hồi không bao giờ được thêm lại vì reload.

Chứng chỉ gia hạn (ACME/remote) không còn làm inbound bị thay thế ở lần reload
sau nếu file chứng chỉ đã đổi quá 1 giờ 5 phút: Xray đã tự nạp lại chứng chỉ
mỗi giờ. Nếu chứng chỉ vừa đổi trong vòng một giờ, inbound vẫn được thay thế để
phục vụ ngay chứng chỉ mới.

## Gỡ giới hạn tốc độ áp dụng ngay cho kết nối đang mở

Từ v1.37.92, khi người dùng chuyển sang gói không giới hạn, giới hạn tạm thời
hết hạn về mức không giới hạn hoặc người dùng bị xoá, bucket của các kết nối
đang mở được gỡ ngay; trước đây các luồng dài (mux, QUIC, tải lớn) vẫn bị giới
hạn cho tới khi app kết nối lại. Giới hạn tạm thời đặt sau khi bucket đã tồn
tại cũng được áp dụng cho kết nối mới.

## Cách ly batch traffic bị panel từ chối vĩnh viễn

Báo cáo traffic là batch bất biến: ZNode giữ nguyên batch và report ID cho đến
khi panel ACK, nên lỗi mạng hay `5xx` không làm mất hoặc tính trùng byte. Từ
v1.37.85, khi panel trả `400`, `413` hoặc `422` (payload bị từ chối vì chính
nội dung batch, ví dụ `Invalid server traffic rate`) ba lần liên tiếp cho cùng
một report ID, ZNode ghi batch đó ra file cách ly
`<spool>.rejected-<report_id>.json` (cùng thư mục spool, quyền `0600`, kèm mã
trạng thái, thông điệp và các cặp `uid/upload/download`) rồi đẩy batch kế tiếp
lên. Hàng đợi traffic phía sau không còn bị một batch hỏng chặn vô thời hạn.
Mọi lỗi khác (`401/403`, `409`, `426`, `429`, `5xx`, lỗi mạng) đặt lại bộ đếm và
tiếp tục retry; nếu không ghi được file cách ly, batch vẫn được giữ và thử lại ở
tick sau. Log: `Traffic report rejected by the panel; immutable batch retained
for retry before quarantine` (cảnh báo, kèm `rejections=n/3`) rồi `Traffic
report was rejected permanently by the panel; immutable batch quarantined`
(kèm `path`). Operator kiểm tra `ls /var/lib/znode/traffic/*.rejected-*.json`
và xử lý nguyên nhân phía panel trước khi nhập lại nếu cần.

## Reload runtime: lý do và hoàn tất thu hồi user dở dang

Khi manifest ZBoard thay đổi, ZNode cố gắng thay chỉ inbound bị đổi trên core
Xray đang chạy. Từ v1.37.85, dòng cảnh báo `Runtime change requires full Xray
core reload` luôn kèm `reason=` nêu rõ điều kiện ép reload toàn bộ (ví dụ
`outbound "default-out" changed`, `WireGuard outbound "wg-1" added`,
`shared connection policy (ConnectionConfig) changed`, `inbound "node-12": UDP
content sniffing policy changed`, `TLS material changed without per-node
provenance`). Ngoài ra, nếu một inbound còn user thu hồi dở dang vì lần ghi
spool trước thất bại, ZNode hoàn tất thu hồi đó (giới hạn 10 giây) trước khi
chuẩn bị reload thay vì để điều kiện này ép reload toàn bộ và rớt mọi khách
trên VPS; nếu vẫn thất bại thì log `Could not complete pending user revocation
before reload` và giữ hành vi cũ.

## Thêm/gỡ node không restart Xray core

Từ v1.37.94, gán thêm hoặc gỡ một node logic khỏi VPS, đổi thứ tự node, hay
đổi route/DNS của một node không còn restart toàn bộ Xray core. ZNode cài DNS
resolver theo node, luật route và outbound mới lên core đang chạy (cache DNS
của node không đổi được giữ nguyên), rồi mới mở inbound của node mới; node bị
gỡ được đóng (drain và ghi spool traffic) trước khi DNS/route của nó bị xoá.
Chỉ inbound của node được thêm, gỡ hoặc đổi cấu hình bị khởi động lại; phiên
của các node khác trên VPS vẫn giữ nguyên. Nếu một inbound mới không mở được,
ZNode khôi phục DNS/route cũ và các inbound cũ. Log: `Applied shared
routing/DNS change without restarting Xray core` kèm `added_nodes`,
`removed_nodes`, `added_outbounds`, `removed_outbounds`.

Vẫn reload toàn bộ core (kèm `reason=`) khi: thêm/gỡ/đổi outbound WireGuard
hoặc balancer WireGuard và observatory, đổi một outbound dùng chung cùng tag,
đổi `ConnectionConfig`/policy/log, hoặc thay đổi thiết lập DNS chung.

## Gộp IPv4 cùng dải nhà mạng

Từ v1.37.95, các IPv4 công khai cùng một dải (mặc định /24) được tính là một
IP bí danh, giống IPv6 vốn đã gộp theo /64. Nhà mạng di động (nhất là ở Trung
Quốc) đổi IP ra ngoài của điện thoại theo từng kết nối trong cùng một pool
CGNAT, nên trước đây một máy có thể chạm giới hạn "Số IP/NAT bí danh" và bị
từ chối kết nối (app báo timeout). Đổi dải ở Admin → Cấu hình → "Gộp IPv4
cùng dải (/16–/32)"; /32 giữ cách tính từng địa chỉ như cũ. IP nội bộ và
loopback vẫn tính từng địa chỉ. ZNode nhận giá trị mới ở lần đồng bộ kế tiếp.

## Tự dọn RAM khi VPS quá tải

Từ v1.37.95, ZNode đo RAM của VPS mỗi 15 giây (MemTotal − MemAvailable). Nếu
mức dùng ở từ 90% trở lên liên tục 5 phút, ZNode trả heap rảnh của nó về hệ
điều hành, `sync` rồi xả page cache sạch (`drop_caches`, cần root). Sau đó
phải đủ thêm 5 phút liền trên 90% mới dọn lần nữa. Không ngắt kết nối hay
restart gì. Log: `Memory guard freed RAM after sustained high usage` kèm
`before`/`after` (%). Nếu RAM vẫn cao sau khi dọn thì phần lớn là bộ nhớ đang
thật sự được dùng; cần tìm tiến trình chiếm RAM hoặc nâng RAM VPS.

## Cập nhật từ panel không còn báo thất bại nhầm

Từ v1.37.97, lệnh bảo trì từ panel (cập nhật ZNode, cập nhật geodata, rollback)
được đưa cho systemd chạy rồi ZNode đi tiếp ngay (`systemd-run --no-block`),
thay vì đứng chờ. Trước đây ZNode chờ đến khi lệnh chạy xong, nhưng lệnh cập
nhật lại khởi động lại chính ZNode, nên ZNode bị tắt giữa lúc chờ: log ghi
`schedule systemd maintenance: signal: terminated` và panel nhận báo "thất bại"
dù bản mới đã chạy. Giờ ZNode báo "đã lên lịch" trước khi khởi động lại, rồi
tiến trình mới báo "hoàn tất" (hoặc lỗi thật, kèm
`/var/log/znode-maintenance.log`).

## Relay UDP PROXY v2

Với Hysteria2 hoặc TUIC qua relay SNAT, chạy relay tích hợp để gửi PROXY v2 UDP
trên từng datagram:

```bash
znode udp-relay --network udp4 --listen :443 --upstream ZNODE_IPV4:443 --ttl 2m --max-flows 512
```

Bật `acceptProxyProtocol: true` và nhập `proxyProtocolTrustedIPs` (IP/CIDR
relay, không wildcard) ở node UDP trên ZBoard sau khi relay và ZNode đã nâng
cấp. Cổng backend vẫn phải firewall cho relay; khi bật, ZNode loại raw UDP,
header không hợp lệ và peer không thuộc allow-list. Chạy service `udp4` và
`udp6` riêng nếu cần cả hai family. Xem `web/docs/DEPLOYMENT_VI.md` trong
workspace để có thứ tự rollout và ví dụ systemd/LimitNOFILE.

## Relay TCP PROXY v1 qua IPv6 → IPv4

Với Shadowsocks hoặc inbound TCP khác đi qua relay nhận IPv6 rồi chuyển tới
ZNode IPv4, relay phải chèn PROXY v1 trước dữ liệu giao thức. ZNode chấp nhận
dạng `PROXY TCP6 <client-ipv6> <backend-ipv4> <client-port> <server-port>` và
chuyển địa chỉ client IPv6 cho giới hạn thiết bị. Nếu chỉ DNAT/port-forward mà
không chèn header, không bật `acceptProxyProtocol`; header là bắt buộc và kết
nối sẽ bị loại trước khi Shadowsocks đọc payload mã hoá. Cổng backend chỉ nên
cho phép IP relay truy cập.

## Phát hành

GitHub Actions build binary theo kiến trúc khi push mã Go lên nhánh `main` hoặc
khi tạo Release. Để installer hoạt động, repository cần có ít nhất một GitHub
Release chứa các tệp `znode-linux-<arch>.zip` do workflow tạo ra.

## Cấu hình Redis

ZBoard và ZNode phải dùng cùng Redis nếu bật đồng bộ thiết bị thời gian thực.
Giữ cùng channel đã cấu hình trên panel, mặc định `v2board:device-sync`.

Thông tin Agent được lưu tại `/etc/znode/config.json` với quyền `0600`. Không
chia sẻ Agent token hoặc sao chép file này sang VPS khác.
Mọi cấu hình hợp lệ phải có trường `"type": "zboard"` ở cấp cao nhất.

Sau lần khởi động online thành công, ZNode ghi snapshot nguyên tử tại
`/var/lib/znode/runtime.snapshot`. File có quyền `0600`, được xác thực HMAC bằng
Agent token và chỉ được dùng khi API ZBoard không truy cập được. Snapshot không
có thời hạn tự hết hiệu lực để VPS tiếp tục phục vụ trong sự cố dài; khi panel
trở lại, các task tự đồng bộ cấu hình, user và traffic đang chờ. Chỉ phản hồi
thu hồi Agent có marker riêng từ ứng dụng ZBoard mới được phép gỡ các inbound;
trang lỗi `401/403` chung từ CDN/WAF không làm node dừng. Phía ZBoard chỉ gắn
marker này khi thật sự tìm thấy Agent bị vô hiệu/xóa hoặc token không khớp;
thiếu header, sai `type` panel hoặc runtime không hỗ trợ trả `401` không marker
để ZNode giữ cấu hình last-known-good và retry.

Traffic protocol 2 phân biệt `409 traffic_report_processing` (tiếp tục giữ và
retry cùng batch) với `409 traffic_report_payload_changed` (xung đột payload cần
operator kiểm tra). Khi một kết nối Hysteria kết thúc vì QUIC idle timeout,
ZNode ghi thêm IP khách, RTT, packet loss và byte counters để phân biệt mất
đường UDP thật với lỗi định tuyến WireGuard ở tầng sau.

## Giấy phép

Xem [LICENSE](LICENSE). Dự án sử dụng Xray core đã tùy chỉnh theo khai báo trong
`go.mod`.

## Dữ liệu GeoIP và GeoSite

Các rule Xray dùng `geoip:` và `geosite:` cần đồng thời hai file
`geoip.dat` và `geosite.dat`. Bản phát hành tự tải dữ liệu mới nhất từ
Loyalsoldier, trình cài đặt xác thực file không rỗng rồi đặt chúng tại
`/etc/znode`. Znode tự đặt `XRAY_LOCATION_ASSET` về thư mục chứa đủ hai file;
Docker image cũng đóng gói sẵn dữ liệu vào `/etc/znode`.

Khi chạy Docker, phải gắn volume bền vững vào `/var/lib/znode`, ví dụ
`-v znode-data:/var/lib/znode`. Đây là nơi lưu batch traffic chưa được ZBoard
xác nhận; không mount thư mục này sẽ làm mất batch đang chờ khi thay container.

Có thể đổi nguồn tải khi cài bằng biến `ZNODE_GEODATA_URL`, ví dụ một mirror
nội bộ có cấu trúc `.../geoip.dat` và `.../geosite.dat`.
