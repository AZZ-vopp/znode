# ZNode

ZNode là agent dành cho [AZZ-vopp/zboard](https://github.com/AZZ-vopp/zboard),
hỗ trợ chạy nhiều logical node trên một VPS và giới hạn thiết bị phân tán qua
Redis.

## Tính năng

- Một agent quản lý nhiều logical node trên cùng VPS.
- Từ chối node trùng port trước khi áp dụng cấu hình.
- Giới hạn IP/HWID/UUID thiết bị qua Redis.
- Pub/Sub đồng bộ thay đổi thiết bị gần như tức thời.
- Chia sẻ Redis connection pool giữa các logical node.
- Tối ưu bộ đếm traffic và UDP để giảm CPU/RAM.
- Chặn toàn cục `tiktokmod.pro`, `amemv.com`, `9mod.com`, `tiktok.tps.dv.tech` và
  `update.9mod.com` (gồm subdomain) bằng route-only sniffing HTTP/TLS/QUIC; không
  nhận diện được ECH hoặc kết nối chỉ dùng địa chỉ IP. Cấu hình cũ yêu cầu tắt
  UDP/QUIC sniffing sẽ được ghi cảnh báo và giữ sniffing bật để áp dụng luật.
- Gửi CPU, RAM, disk và tốc độ mạng về ZBoard.
- TLS tự ký và SHA-256 certificate pinning.
- Last-known-good offline runtime: panel mất kết nối hoặc ZNode khởi động lại
  trong lúc web sập vẫn giữ node và user cuối cùng hoạt động.
- Chỉ kết nối với ZBoard bằng nhận diện hai chiều, không chạy với V2Board gốc.

Xem thêm [tài liệu Redis và tối ưu UDP](docs/ZNODE_REDIS_UDP_VI.md).

## Cài đặt

Khuyến nghị tạo Agent/VPS trong ZBoard rồi sử dụng đúng lệnh cài đặt được sinh
trên màn hình Admin. Cài thủ công installer:

```bash
wget -N https://raw.githubusercontent.com/AZZ-vopp/znode/main/script/install.sh
bash install.sh
```

Cài agent bằng thông tin do ZBoard cấp. Token được đọc qua stdin để không xuất
hiện trong shell history hoặc danh sách process:

```bash
read -rsp 'Agent token: ' ZNODE_AGENT_TOKEN; echo
printf '%s\n' "$ZNODE_AGENT_TOKEN" | bash install.sh \
  --api-host https://panel.example.com \
  --agent-id AGENT_ID \
  --agent-token-stdin \
  --release-repo AZZ-vopp/znode \
  --release-branch main
unset ZNODE_AGENT_TOKEN
```

Installer lưu repository phát hành trong `/etc/znode/release-repo`; lệnh
`znode update` sau này tiếp tục tải đúng binary từ `AZZ-vopp/znode`.
Installer chỉ chấp nhận gói có tệp `.dgst`, kiểm tra SHA-256 trước khi giải nén
và tải script qua HTTPS có kiểm tra chứng chỉ. Bản trước được giữ tại
`/usr/local/znode.rollback` để có thể khôi phục nếu cần; không tắt kiểm tra TLS
hoặc tự thay URL tải bằng nguồn không tin cậy.

## Buffer UDP của kernel

Linux cấp cho mỗi socket UDP buffer nhận mặc định `net.core.rmem_default`
(208 KiB). Một đợt tải video QUIC hoặc một khách Hysteria2 bận là đủ làm đầy
buffer đó trong vài mili giây; kernel lặng lẽ vứt gói (`UdpRcvbufErrors` tăng
trong `nstat -az`) và khách thấy phiên "mất ping" vài giây rồi tự có lại.

Runtime tự yêu cầu 4 MiB cho mọi socket UDP nó mở (listener Hysteria2/TUIC/
Shadowsocks và socket outbound freedom) qua `SO_RCVBUF`/`SO_SNDBUF`. Kernel giới
hạn yêu cầu đó ở `net.core.rmem_max`/`wmem_max`, nên installer ghi
`/etc/sysctl.d/99-znode-udp.conf` nâng trần và giá trị mặc định (chỉ nâng, không
hạ giá trị operator đã đặt cao hơn) rồi áp ngay bằng `sysctl -p`. Kiểm tra sau
khi cài hoặc cập nhật:

```bash
sysctl net.core.rmem_default net.core.rmem_max
nstat -n; sleep 60; nstat UdpRcvbufErrors   # mong đợi gần 0 drop/phút
```

Node nâng cấp từ bản cũ cần `systemctl restart znode` một lần để listener đang
mở nhận buffer mới; socket outbound tự nhận khi được tạo lại.

## TCP của kernel cho VPS proxy

Từ v1.37.111, installer (chạy cả khi cập nhật) ghi thêm
`/etc/sysctl.d/zz-znode-tuning.conf`. Tên `zz-` để file này được đọc sau các
file của script relay cài chung (ví dụ `ny.conf` của nyanpass) khi khởi động.

- `tcp_mem` = 10% / 13% / 20% RAM. Mặc định của kernel chỉ khoảng 9%, nên VPS
  1 GB với vài trăm kết nối hay chạm trần. Khi đó kernel bỏ gói và khách thấy
  tải lên bị khựng. Giá trị này chỉ được nâng, không bao giờ hạ.
- `tcp_adv_win_scale = 1`: một nửa buffer dùng làm cửa sổ. `ny.conf` đặt `-2`,
  tức buffer phải gấp 4 lần cửa sổ.
- Buffer mỗi socket tối đa 8 MiB (16 MiB khi RAM trên 2,5 GB).
- `tcp_notsent_lowat = 128 KiB`, `tcp_slow_start_after_idle = 0`,
  `tcp_mtu_probing = 1`, `tcp_frto = 2`, `tcp_fin_timeout = 30`.
- `tcp_max_tw_buckets`, `rmem_max` và `wmem_max` được ghi lại để file đọc
  trước không hạ chúng xuống. Các giá trị này chỉ được nâng.
- BBR + fq chỉ được bật khi VPS đang dùng `cubic`/`reno`. Thuật toán operator
  đã tự chọn thì giữ nguyên.

Đo trên VPS Lightsail HK 1 GB: thời gian thiếu bộ nhớ TCP giảm từ 2,4 giờ
trong 6 ngày xuống 0. Gói bị bỏ khi khách tải lên giảm về 0. Tỷ lệ gửi lại
giảm từ 2,5% xuống 1,4%.

Nếu muốn giữ cấu hình TCP của riêng mình, chạy
`touch /etc/znode/no-tcp-tuning` rồi chạy lại installer. Installer sẽ xoá file
`zz-` của nó. Giá trị đang chạy giữ đến lần khởi động lại sau.

## Biên dịch

Yêu cầu Go 1.27.3. `encoding/json/v2` đã ổn định từ Go 1.27:

```bash
./script/with-xray-core.sh go test ./...
./script/with-xray-core.sh go build -v -o build_assets/znode \
  -trimpath \
  -ldflags "-X 'github.com/AZZ-vopp/znode/cmd.version=dev' -s -w -buildid="
```

Wrapper trên dùng cùng nhánh lõi với v2node hiện tại: fork
`github.com/wyx2685/xray-core` tại snapshot
`v0.0.0-20260930151924-e087e74a1bf2`, có AnyTLS/TUIC. Sau đó wrapper áp các
backport đã kiểm tra trong `patches/xray-core` vào bản sao tạm. Module cache gốc
không bị sửa. Wrapper cũng áp patch tương thích REALITY trong `patches/reality`
vào bản sao tạm của dependency đã ghim, giữ khả năng kết nối X25519 cũ của
V2Node cùng với client hỗ trợ khóa lai mới. Patch đã có sẵn sẽ được bỏ qua, còn
patch không tương thích sẽ làm build dừng ngay.

## Admission REALITY trước xác thực

Mỗi kết nối TCP tới inbound REALITY phải đi qua handshake trước khi được xác
thực; trong lúc đó ZNode dial đích giả trang và giữ một slot trong pool toàn
tiến trình, dùng chung cho mọi logical node trên host. Client không bật mux mở
một handshake cho mỗi kết nối TCP, nên cơn bão reconnect sau một lần mất mạng
ngắn dễ vượt pool cũ 128 slot; socket dư khi đó bị reset im lặng và người dùng
thấy "mất mạng đột ngột" dù node vẫn chạy. Patch
`patches/xray-core/zzzzz-reality-admission-capacity.patch` đổi hành vi này:

- Pool 1024 slot handshake đang chờ xác thực (trước đây 128).
- Socket đến khi pool đầy chờ tối đa 2 giây để nhận slot theo thứ tự đến, thay
  vì bị đóng ngay; hàng chờ tối đa 4096 socket, quá ngưỡng mới đóng tức thì.
- Khi vẫn phải đóng, ZNode ghi cảnh báo `REALITY pre-auth admission ...` kèm
  tổng số socket đã đóng, tối đa 10 giây một dòng. Trước đây không có log.

Kiểm tra trên node: `journalctl -u znode --since -1h | grep -c "REALITY pre-auth
admission"`; con số tăng nghĩa là node đang bị quét hoặc bão reconnect vượt cả
pool mới, cần xem `REALITY: processed invalid connection` để phân biệt scanner
với client hợp lệ. Thời gian chờ handshake 15 giây cho dial đích và ClientHello
không đổi.

## Không giới hạn số phiên (giống v2node)

ZNode không còn giới hạn số phiên mỗi tài khoản hay toàn node. Trước đây trần
mặc định 512 phiên mỗi UUID (tính cả association UDP giữ tới hết `ConnIdle`
300 giây) làm khách xem video hoặc dùng nhiều luồng QUIC bị rớt giữa chừng:
VLESS bị từ chối kết nối mới, còn Hysteria2 bị bỏ datagram không báo lỗi.

Các khoá `MaxConnectionsPerUser` và `MaxConnections` trong `ConnectionConfig`
của `/etc/znode/config.json` vẫn được đọc để file cũ không lỗi nhưng bị bỏ qua.
Bộ cài mới không ghi hai khoá này. Giới hạn thiết bị/IP của panel và
`LimitNOFILE=262144` của systemd vẫn áp dụng.

## WireGuard `domainStrategy` (giống v2node)

Từ v1.37.87, `settings.domainStrategy` trong outbound WireGuard được áp dụng
thật: ZNode chuyển nó thành `targetStrategy` của outbound để Xray phân giải tên
miền đích bằng DNS của node trước khi vào tunnel (trước đây giá trị bị bỏ qua
và tên miền được phân giải qua `remoteDNS` trong tunnel, gây lỗi
`lookup ... on 1.0.0.1: i/o timeout`). Bỏ trống thì mặc định `ForceIPv4`; nhận
`AsIs`, `UseIP`, `UseIPv4`, `UseIPv4v6`, `ForceIP`, `ForceIPv4`, `ForceIPv4v6`.
Giá trị ưu tiên IPv6 bị từ chối vì tunnel chỉ có IPv4.

## Đồng bộ người dùng bền hơn

Từ v1.37.88:

- Xoá một người dùng bị lỗi (drain/RemoveUser hết hạn) không còn chặn việc
  thêm người mới; người dùng được thêm từng người, một người bị Xray từ chối
  chỉ bị bỏ qua và thử lại ở lượt sau.
- Danh sách từ panel có dòng hỏng hoặc UUID trùng: bỏ dòng đó (giữ dòng đầu),
  vẫn áp dụng phần còn lại thay vì giữ nguyên danh sách cũ.
- Snapshot Redis dùng khi panel mất kết nối chỉ được **thêm** người dùng, không
  xoá hay sửa người đang có; revision chưa được đánh dấu đã xử lý cho tới khi
  panel trả danh sách thật.
- Đổi report ID của cùng một UUID được cập nhật tại chỗ, không ngắt phiên.
- Gia hạn chứng chỉ ACME dùng lại private key hiện có.
- Từ v1.37.89: một người dùng bị Xray từ chối cũng không còn làm inbound
  không khởi động được khi restart/reload; người đó bị bỏ qua và thử lại sau.
- Từ v1.37.90: người dùng mới/được thay đổi được thêm **trước** khi xoá người
  hết hạn, nên một loạt xoá chậm (mỗi người tối đa 5 giây drain) không còn làm
  hết hạn lượt đồng bộ trước khi kịp thêm người vừa gia hạn hoặc mua mới.
- Từ v1.37.90: người dùng bị xoá dở (drain chưa xong) mà panel liệt kê lại (gia
  hạn ngay) được huỷ lệnh xoá và cho kết nối lại, thay vì bị chặn trên node đó
  cho tới khi drain thành công.

## Giới hạn tốc độ

Từ v1.37.90, giới hạn tốc độ của mỗi người dùng tách riêng chiều tải lên và
tải xuống, nạp token liên tục thay vì mỗi giây một lần, và mỗi lần ghi chỉ giữ
chỗ tối đa 16 KiB. Trước đây một luồng tải nặng làm kết nối mới của cùng người
dùng (bắt tay TLS/REALITY, ping) phải chờ vài giây sau phần nợ token, trông
như timeout trên gói có giới hạn tốc độ.

## Một node chạy trên nhiều VPS

Node có nhiều instance Agent (`load_agent_ips`) chỉ công bố một mã pin
chứng chỉ cho khách hàng. Trước v1.37.91 mỗi VPS giữ chứng chỉ tự ký riêng và
lượt `sync` vault đẩy chứng chỉ cục bộ lên, nên vault và mã pin bị các VPS
thay nhau ghi đè: khách chỉ kết nối được VPS trùng pin, còn lại báo lỗi TLS
hoặc timeout.

Từ v1.37.91, khi panel gửi `adopt_vault` (chỉ với `cert_mode` `self`, `auto`,
`dns`, `http` và vault đã có chứng chỉ) mà chứng chỉ cục bộ là tự ký và khác
vault, ZNode tải cặp chứng chỉ từ vault, kiểm tra SHA-256 khớp
`expected_sha256`, đổi tên cặp cũ thành `*.replaced-<thời gian>` rồi ghi cặp
mới nguyên tử và nạp lại runtime. Mọi VPS khi đó phục vụ cùng chứng chỉ đã
pin. Chứng chỉ do CA cấp (ACME gia hạn) vẫn được đẩy lên vault như trước. Nếu
tải vault thất bại, ZNode giữ nguyên cặp cục bộ và không đẩy đè vault; lượt
manifest sau sẽ thử lại. Panel cũ không gửi cờ này nên ZNode giữ hành vi cũ;
cần cập nhật Web trước rồi mới cập nhật ZNode.

Từ v1.37.92, lỗi khi đẩy cặp chứng chỉ đang chạy lên vault (VPS anh em đã
dùng nonce, panel từ chối, cặp cục bộ không đọc được) chỉ ghi cảnh báo và bỏ
qua node đó. Trước đây lỗi này làm Agent bỏ qua toàn bộ manifest: node mới,
đổi cổng/SNI, fallback không được áp dụng và mọi lần reload đều thất bại. Lỗi
khôi phục khi VPS chưa có chứng chỉ vẫn dừng lại như cũ, để không tự sinh
chứng chỉ mới làm sai mã pin.

## Reload không phụ thuộc danh sách thiết bị online

Từ v1.37.92, nếu panel không trả được `alivelist` khi chuẩn bị reload, ZNode
vẫn reload với số thiết bị trống (đợt đồng bộ định kỳ nạp lại) thay vì làm
thất bại reload của mọi node. Controller đang chạy giữ số đếm cũ.

## Reload tại chỗ khi còn lệnh xoá người dùng dở dang

Từ v1.37.92, một lệnh xoá người dùng chưa drain xong không còn biến mọi thay
đổi trên panel thành restart toàn bộ Xray. Inbound không đổi giữ nguyên
controller cùng lệnh xoá đang chờ (đợt đồng bộ định kỳ tiếp tục thử); inbound
bị thay thế loại người dùng đó khỏi danh sách của inbound mới. Người dùng đã
bị thu hồi không bao giờ được thêm lại vì reload.

Chứng chỉ gia hạn (ACME/remote) không còn làm inbound bị thay thế ở lần reload
sau nếu file chứng chỉ đã đổi quá 1 giờ 5 phút: Xray đã tự nạp lại chứng chỉ
mỗi giờ. Nếu chứng chỉ vừa đổi trong vòng một giờ, inbound vẫn được thay thế để
phục vụ ngay chứng chỉ mới.

## Gỡ giới hạn tốc độ áp dụng ngay cho kết nối đang mở

Từ v1.37.92, khi người dùng chuyển sang gói không giới hạn, giới hạn tạm thời
hết hạn về mức không giới hạn hoặc người dùng bị xoá, bucket của các kết nối
đang mở được gỡ ngay; trước đây các luồng dài (mux, QUIC, tải lớn) vẫn bị giới
hạn cho tới khi app kết nối lại. Giới hạn tạm thời đặt sau khi bucket đã tồn
tại cũng được áp dụng cho kết nối mới.

## Cách ly batch traffic bị panel từ chối vĩnh viễn

Báo cáo traffic là batch bất biến: ZNode giữ nguyên batch và report ID cho đến
khi panel ACK, nên lỗi mạng hay `5xx` không làm mất hoặc tính trùng byte. Từ
v1.37.85, khi panel trả `400`, `413` hoặc `422` (payload bị từ chối vì chính
nội dung batch, ví dụ `Invalid server traffic rate`) ba lần liên tiếp cho cùng
một report ID, ZNode ghi batch đó ra file cách ly
`<spool>.rejected-<report_id>.json` (cùng thư mục spool, quyền `0600`, kèm mã
trạng thái, thông điệp và các cặp `uid/upload/download`) rồi đẩy batch kế tiếp
lên. Hàng đợi traffic phía sau không còn bị một batch hỏng chặn vô thời hạn.
Mọi lỗi khác (`401/403`, `409`, `426`, `429`, `5xx`, lỗi mạng) đặt lại bộ đếm và
tiếp tục retry; nếu không ghi được file cách ly, batch vẫn được giữ và thử lại ở
tick sau. Log: `Traffic report rejected by the panel; immutable batch retained
for retry before quarantine` (cảnh báo, kèm `rejections=n/3`) rồi `Traffic
report was rejected permanently by the panel; immutable batch quarantined`
(kèm `path`). Operator kiểm tra `ls /var/lib/znode/traffic/*.rejected-*.json`
và xử lý nguyên nhân phía panel trước khi nhập lại nếu cần.

## Reload runtime: lý do và hoàn tất thu hồi user dở dang

Khi manifest ZBoard thay đổi, ZNode cố gắng thay chỉ inbound bị đổi trên core
Xray đang chạy. Từ v1.37.85, dòng cảnh báo `Runtime change requires full Xray
core reload` luôn kèm `reason=` nêu rõ điều kiện ép reload toàn bộ (ví dụ
`outbound "default-out" changed`, `WireGuard outbound "wg-1" added`,
`shared connection policy (ConnectionConfig) changed`, `inbound "node-12": UDP
content sniffing policy changed`, `TLS material changed without per-node
provenance`). Ngoài ra, nếu một inbound còn user thu hồi dở dang vì lần ghi
spool trước thất bại, ZNode hoàn tất thu hồi đó (giới hạn 10 giây) trước khi
chuẩn bị reload thay vì để điều kiện này ép reload toàn bộ và rớt mọi khách
trên VPS; nếu vẫn thất bại thì log `Could not complete pending user revocation
before reload` và giữ hành vi cũ.

## Thêm/gỡ node không restart Xray core

Từ v1.37.94, gán thêm hoặc gỡ một node logic khỏi VPS, đổi thứ tự node, hay
đổi route/DNS của một node không còn restart toàn bộ Xray core. ZNode cài DNS
resolver theo node, luật route và outbound mới lên core đang chạy (cache DNS
của node không đổi được giữ nguyên), rồi mới mở inbound của node mới; node bị
gỡ được đóng (drain và ghi spool traffic) trước khi DNS/route của nó bị xoá.
Chỉ inbound của node được thêm, gỡ hoặc đổi cấu hình bị khởi động lại; phiên
của các node khác trên VPS vẫn giữ nguyên. Nếu một inbound mới không mở được,
ZNode khôi phục DNS/route cũ và các inbound cũ. Log: `Applied shared
routing/DNS change without restarting Xray core` kèm `added_nodes`,
`removed_nodes`, `added_outbounds`, `removed_outbounds`.

Vẫn reload toàn bộ core (kèm `reason=`) khi: thêm/gỡ/đổi outbound WireGuard
hoặc balancer WireGuard và observatory, đổi một outbound dùng chung cùng tag,
đổi `ConnectionConfig`/policy/log, hoặc thay đổi thiết lập DNS chung.

## Gộp IPv4 cùng dải nhà mạng

Từ v1.37.95, các IPv4 công khai cùng một dải (mặc định /24) được tính là một
IP bí danh, giống IPv6 vốn đã gộp theo /64. Nhà mạng di động (nhất là ở Trung
Quốc) đổi IP ra ngoài của điện thoại theo từng kết nối trong cùng một pool
CGNAT, nên trước đây một máy có thể chạm giới hạn "Số IP/NAT bí danh" và bị
từ chối kết nối (app báo timeout). Đổi dải ở Admin → Cấu hình → "Gộp IPv4
cùng dải (/16–/32)"; /32 giữ cách tính từng địa chỉ như cũ. IP nội bộ và
loopback vẫn tính từng địa chỉ. ZNode nhận giá trị mới ở lần đồng bộ kế tiếp.

## Tự dọn RAM khi VPS quá tải

Từ v1.37.95, ZNode đo RAM của VPS mỗi 15 giây (MemTotal − MemAvailable). Nếu
mức dùng ở từ 90% trở lên liên tục 5 phút, ZNode trả heap rảnh của nó về hệ
điều hành, `sync` rồi xả page cache sạch (`drop_caches`, cần root). Sau đó
phải đủ thêm 5 phút liền trên 90% mới dọn lần nữa. Không ngắt kết nối hay
restart gì. Log: `Memory guard freed RAM after sustained high usage` kèm
`before`/`after` (%). Nếu RAM vẫn cao sau khi dọn thì phần lớn là bộ nhớ đang
thật sự được dùng; cần tìm tiến trình chiếm RAM hoặc nâng RAM VPS.

## Giới hạn bộ nhớ mềm cho Go

Khi khởi động, ZNode tự đặt giới hạn bộ nhớ của Go: lấy giá trị nhỏ nhất giữa
50% RAM VPS và 70% ngưỡng systemd (`MemoryHigh`/`MemoryMax`), thấp nhất 128 MB
và cao nhất 1 GiB.
Gần tới giới hạn, Go dọn rác sớm hơn và trả RAM rảnh cho hệ điều hành, thay vì
để heap phình gấp đôi rồi bị kernel bóp ở `MemoryHigh`. Ví dụ VPS 1 GB: khoảng
470 MB. Bộ đệm kết nối và thời gian giữ kết nối không đổi.

Mức trần 1 GiB có từ bản sau v1.37.115. Trước đó, VPS 8 GB nhận giới hạn 4 GB:
Go không có lý do dọn rác hay trả RAM, và các mức bên dưới đều tính cho máy
lớn (GOGC 100, 4096 gói WireGuard). Kết quả là các node 8 GB giữ 1,2–1,6 GB
(06/11/2026). Bài test 400 vòng không thấy rò RAM, và mỗi phiên chỉ tốn khoảng
100 KB, nên 1 GiB vẫn đủ cho khoảng 5000 phiên cùng lúc. Nay mọi VPS từ khoảng
2 GB trở lên được chia RAM như máy 2–3 GB.

Đặt biến môi trường `GOMEMLIMIT` cho dịch vụ thì ZNode dùng giá trị đó. Log khi
khởi động: `Go memory limit set so ZNode returns unused memory early` kèm
`limit_mb`.

## ZNode tự chia RAM theo cấu hình VPS

Khi khởi động, ZNode đọc RAM VPS và giới hạn systemd (`MemoryHigh`/`MemoryMax`),
tính các mức dưới đây rồi ghi một dòng log `Memory budget for this VPS`:

| Mức | Cách tính | VPS 1 GB (high 756 MB) |
|---|---|---|
| Giới hạn mềm của Go | min(50% RAM, 70% systemd), từ 128 MB tới 1 GiB | ~470 MB |
| Trả RAM dư | 85% giới hạn mềm | ~400 MB |
| Khởi động lại | min(80% RAM, 90% systemd) | ~680 MB |
| Bộ đệm TCP WireGuard (gVisor) | theo giới hạn mềm, xem bảng dưới | 256 KiB |

- **Trả RAM dư:** ZNode chiếm (RSS) từ mức này trở lên thì ZNode trả phần heap
  đang rảnh cho hệ điều hành, tối đa mỗi phút một lần. Không ngắt kết nối nào.
- **Khởi động lại:** ZNode vẫn chiếm từ mức này trở lên ở mọi lần đo trong 3
  phút liền (đã trả RAM dư mà không xuống) thì ZNode tắt êm, ghi lại lưu lượng,
  và systemd bật lại sau ~30 giây. Cách này dùng chung giới hạn 3 lần/giờ và điều
  kiện "chỉ khi chạy bằng systemd" với mục bên dưới. Log:
  `Load guard: ZNode stayed above its memory budget; restarting ZNode`.

### Bộ đệm TCP cho route đi qua WireGuard

Khi route đi qua outbound WireGuard và Xray không mở được TUN của kernel (log
`Using gVisor TUN`), mỗi kết nối TCP nằm trong ngăn xếp mạng gVisor. Mặc định
gVisor tự nới bộ đệm nhận lên 4 MiB. Khách xem video trên mạng chậm làm bộ đệm
đầy và nằm yên đó: ~4,3 MiB mỗi kết nối. Patch
`patches/xray-core/wireguard-gvisor-tcp-buffers.patch` cho ZNode chọn cỡ bộ
đệm theo VPS:

| Giới hạn mềm (≈ VPS) | Bộ đệm | RAM mỗi kết nối kẹt | Trần mỗi kết nối ở ping 50 ms |
|---|---|---|---|
| ≤ 640 MB (≤ ~1,25 GB) | 256 KiB cố định | ~0,4 MiB | ~40 Mbit/s |
| ≤ 1,5 GB (≤ ~3 GB) | 512 KiB cố định | ~0,7 MiB | ~80 Mbit/s |
| ≤ 4 GB (chỉ khi đặt `GOMEMLIMIT`) | 256 KiB, tự nới tới 1 MiB | ~1,2 MiB | ~160 Mbit/s |
| lớn hơn (chỉ khi đặt `GOMEMLIMIT`) | 256 KiB, tự nới tới 2 MiB | | ~320 Mbit/s |

Mỗi kết nối chạy tối đa bằng cỡ bộ đệm chia cho ping. Tổng tốc độ của node
không giảm, và kết nối ở gần (ping 5–10 ms) vẫn trên 200 Mbit/s. Đo trên máy
(ping ≈ 0), một kết nối tải nhanh đạt ~750 Mbit/s ở mọi mức. Bản cũ chỉ đạt
~440 Mbit/s vì heap phình 850 MiB.

Muốn tự đặt cỡ bộ đệm thì đặt `ZNODE_WG_TCP_BUFFER` cho dịch vụ: `512K` (cố
định), `256K:2M` (tự nới) hoặc `default` (như gVisor gốc). Chạy dưới quyền root
trên Linux thì Xray dùng TUN của kernel (log `Using kernel TUN`), và mục này
không đổi gì. Đo lại:

```bash
ZNODE_WG_TCP_BUFFER=256K ZNODE_MEMPROFILE=/tmp/wg.pb.gz ./script/with-xray-core.sh go test ./core -run 'TestMemoryPerWireGuardSession$|TestMemoryWireGuardServerHelper$' -v
```

## Tự khởi động lại ZNode khi CPU hoặc RAM 95% suốt 5 phút

ZNode đo CPU toàn máy (`/proc/stat`) và RAM mỗi 15 giây. Nếu CPU **hoặc** RAM
ở từ 95% trở lên ở mọi lần đo trong 5 phút liền, ZNode tắt êm (ghi lại lưu
lượng như khi nhận SIGTERM) rồi thoát với mã lỗi. systemd
(`Restart=on-failure`, `RestartSec=30`) bật lại sau khoảng 30 giây, nên node
mất kết nối chừng 30–45 giây. Chỉ cần một lần đo dưới 95% là đếm lại từ đầu.

- Chỉ chạy khi ZNode do systemd khởi động. Chạy tay thì chỉ ghi log, không tắt.
- Tối đa 3 lần trong 1 giờ (ghi ở `/var/lib/znode/loadguard-restarts`). Nếu
  quá tải do tiến trình khác trên VPS, ZNode không bị tắt/bật liên tục.
- Log: `Load guard: CPU or RAM stayed at or above 95% for 5 minutes; restarting ZNode`
  kèm `cpu`/`ram` (%).
- Từ v1.37.111, CPU bị máy chủ ảo hoá lấy lại (`steal`) không tính là bận. VPS
  có CPU burst (AWS Lightsail, EC2 T) hết credit thì bị lấy tới khoảng 90% CPU;
  trước đây ZNode coi đó là "cpu 98%" và tự khởi động lại, làm rớt mọi khách mà
  không lấy lại được CPU. Panel vẫn hiện cả phần bị lấy, để thấy VPS đang bị
  giới hạn CPU.

## Khởi động lại ZNode từ panel

Từ v1.37.101, ZNode báo với panel là hỗ trợ khởi động lại từ xa (capability
`restart`). Nút "Khởi động lại toàn bộ ZNode" ở tab VPS Agent chỉ bấm được khi
ít nhất một VPS online đã chạy bản này. Khi nhận lệnh, ZNode chờ ngẫu nhiên
5–60 giây rồi chạy `znode restart` trong một unit systemd riêng. Các VPS vì vậy
không khởi động lại cùng lúc, nên khách không ồ ạt kết nối lại một lượt. Bản
ZNode mới sau khi chạy lên báo "hoàn tất" về panel. Lỗi thì xem
`/var/log/znode-maintenance.log`.

## Chỉ gọi panel qua IPv4 (VPS AWS Lightsail/EC2)

Từ v1.37.102, ZNode chỉ kết nối tới panel bằng IPv4. IPv4 chậm hay lỗi tạm thời
thì ZNode thử lại bằng IPv4, không chuyển sang IPv6. Chỉ VPS hoàn toàn không có
IPv4 (không có route IPv4) mới dùng IPv6. Bản v1.37.101 vẫn chuyển sang IPv6 sau
5 giây. Lý do:

- VPS AWS Lightsail/EC2 chỉ có IPv4 nội bộ (172.26.x.x) trên card mạng. IPv4
  công khai chỉ được panel nhìn thấy qua kết nối.
- Trước đây VPS có IPv6 nên ZNode gọi panel qua IPv6. Panel chỉ biết IPv6 của
  VPS, nên khi đổi static IP thì cột "Kết nối" và địa chỉ node vẫn giữ IP cũ.
- Giờ panel thấy đúng IPv4 công khai. Khi VPS đổi IP, panel (từ commit
  `ab84674a`) tự chuyển địa chỉ node từ IP cũ sang IP mới.

Lần đầu VPS báo IPv4 sau khi cập nhật, panel chưa từng biết IPv4 cũ, nên địa chỉ
node phải sửa tay một lần. Từ lần đổi IP sau, panel tự đổi theo.

## Cập nhật từ panel không còn báo thất bại nhầm

Từ v1.37.97, lệnh bảo trì từ panel (cập nhật ZNode, cập nhật geodata, rollback)
được đưa cho systemd chạy rồi ZNode đi tiếp ngay (`systemd-run --no-block`),
thay vì đứng chờ. Trước đây ZNode chờ đến khi lệnh chạy xong, nhưng lệnh cập
nhật lại khởi động lại chính ZNode, nên ZNode bị tắt giữa lúc chờ: log ghi
`schedule systemd maintenance: signal: terminated` và panel nhận báo "thất bại"
dù bản mới đã chạy. Giờ ZNode báo "đã lên lịch" trước khi khởi động lại, rồi
tiến trình mới báo "hoàn tất" (hoặc lỗi thật, kèm
`/var/log/znode-maintenance.log`).

## Cập nhật từ panel được giãn ngẫu nhiên

Mỗi lần cập nhật, ZNode khởi động lại và mọi khách trên VPS đó kết nối lại cùng
lúc. Nếu panel gửi cùng một lệnh cập nhật cho nhiều VPS, các VPS sẽ khởi động lại
gần như đồng thời và một lượng lớn kết nối mới dồn vào cùng một cổng trong vài
giây, dễ bị tường lửa (GFW) để ý. Từ bản sau v1.37.97, lệnh cập nhật ZNode và cập
nhật geodata chờ ngẫu nhiên **15 giây đến 5 phút** rồi mới chạy; panel hiện số
giây chờ trong thông báo "đã lên lịch". Rollback vẫn chạy sau 2 giây. Thời điểm
chạy thật (`run_at`) được ghi vào `/var/lib/znode/maintenance.json`, nên ZNode
sau khi khởi động lại vẫn chờ kết quả đủ 2 phút tính từ lúc lệnh chạy, không báo
thất bại nhầm khi lệnh còn đang chờ đến lượt.

Vẫn nên cập nhật từng nhóm VPS thay vì tất cả một lúc.

## Reality tên miền riêng

Reality thường mượn trang của người khác (ví dụ một trang lớn) làm đích. Cách
này để lộ hai dấu hiệu rẻ tiền cho tường lửa:

- máy quét Internet thấy chứng chỉ của trang lớn đó trên IP và cổng của VPS;
- SNI không bao giờ phân giải DNS ra IP của node.

Khi panel gửi `tls_settings.reality_self = "1"`, ZNode mượn chính trang web của
mình thay vì trang người khác:

- ZNode chạy một trang web tĩnh nhỏ trên unix socket nội bộ
  (`/run/znode/reality-<mã>.sock`, quyền 0600). Trang hỗ trợ TLS 1.3 và HTTP/2,
  dùng chứng chỉ thật của tên miền node, cấp qua Auto TLS DNS-01 của panel và
  tự gia hạn như node TLS.
- Đích Reality trỏ vào socket đó. Panel tự trỏ bản ghi A/AAAA của tên miền về IP
  Agent (không proxy).
- Kết quả: SNI khớp DNS. Máy quét hoặc trình duyệt không phải client Reality sẽ
  thấy chứng chỉ của tên miền node và một trang web bình thường.
- Khi chưa có chứng chỉ thật (đang cấp, hoặc ACME lỗi), trang dùng tạm chứng chỉ
  tự ký để node vẫn chạy.

ZNode gửi capability `reality_self` lên panel. Panel từ chối cấu hình này
(HTTP 409 `unsupported_reality_self`) với ZNode cũ, vì bản cũ sẽ lấy chính tên
miền của node làm đích, tức là tự gọi vòng về mình.

## Trojan / AnyTLS: hiện trang web khi bị dò cổng

Trước đây, kết nối tới cổng Trojan hay AnyTLS mà không đúng mật khẩu (máy quét,
tường lửa dò chủ động, trình duyệt) bị cắt ngay, một dấu hiệu dễ nhận ra.

Từ v1.37.103, node Trojan hoặc AnyTLS dùng TLS trên TCP chuyển các kết nối đó
cho một trang web tĩnh nhỏ chạy ngay trên node (`/run/znode/fallback-<mã>.sock`,
quyền 0600, HTTP/1.1 và HTTP/2). Bên dò thấy chứng chỉ của node và một trang web
bình thường. Khách đúng mật khẩu không bị ảnh hưởng.

- Trojan dùng `fallbacks` của Xray.
- AnyTLS không có fallback ở bản gốc, nên ZNode vá Xray
  (`patches/xray-core/anytls-auth-fallback.patch`).
- Trojan qua WebSocket/gRPC không đổi: các transport đó vốn trả lỗi HTTP.

Dùng tốt nhất với preset "Trojan · tên miền riêng" / "AnyTLS · tên miền riêng"
trên panel: panel tự tạo tên miền, trỏ DNS về VPS và cấp chứng chỉ thật.

## Tốc độ chung cho cả gói

Khi gói bật "tốc độ chung", panel gửi `speed_group` (mã thuê bao) cho mọi user
của gói. Các user cùng nhóm trên cùng một inbound dùng chung một bucket giới hạn
tốc độ (`group:<mã>`); bucket được gỡ khi thành viên cuối rời nhóm. Giới hạn
riêng theo UUID vẫn giữ bucket riêng. Chia sẻ theo từng inbound, không gộp giữa
các node. ZNode cũ bỏ qua `speed_group`.

## IP thật của khách qua CDN Cloudflare

Với node CDN, ZNode dùng trực tiếp header một IP đáng tin (ví dụ
`CF-Connecting-IP`, `X-Real-IP`) thay vì phần tử đầu của `X-Forwarded-For`, vốn
khách có thể giả qua Cloudflare. Áp dụng cho các transport HTTP và gRPC
(`patches/xray-core/trusted-header-client-ip.patch`). Ai gọi thẳng vào VPS vẫn
giả được header, nên hãy chỉ mở cổng CDN cho dải IP của Cloudflare.

## Relay UDP PROXY v2

Với Hysteria2 hoặc TUIC qua relay SNAT, chạy relay tích hợp để gửi PROXY v2 UDP
trên từng datagram:

```bash
znode udp-relay --network udp4 --listen :443 --upstream ZNODE_IPV4:443 --ttl 2m --max-flows 512
```

Bật `acceptProxyProtocol: true` và nhập `proxyProtocolTrustedIPs` (IP/CIDR
relay, không wildcard) ở node UDP trên ZBoard sau khi relay và ZNode đã nâng
cấp. Cổng backend vẫn phải firewall cho relay; khi bật, ZNode loại raw UDP,
header không hợp lệ và peer không thuộc allow-list. Chạy service `udp4` và
`udp6` riêng nếu cần cả hai family. Xem `web/docs/DEPLOYMENT_VI.md` trong
workspace để có thứ tự rollout và ví dụ systemd/LimitNOFILE.

## Relay TCP PROXY v1 qua IPv6 → IPv4

Với Shadowsocks hoặc inbound TCP khác đi qua relay nhận IPv6 rồi chuyển tới
ZNode IPv4, relay phải chèn PROXY v1 trước dữ liệu giao thức. ZNode chấp nhận
dạng `PROXY TCP6 <client-ipv6> <backend-ipv4> <client-port> <server-port>` và
chuyển địa chỉ client IPv6 cho giới hạn thiết bị. Nếu chỉ DNAT/port-forward mà
không chèn header, không bật `acceptProxyProtocol`; header là bắt buộc và kết
nối sẽ bị loại trước khi Shadowsocks đọc payload mã hoá. Cổng backend chỉ nên
cho phép IP relay truy cập.

## Go 1.27.3 và tắt MPTCP (theo v2node 5935d2e)

Từ v1.37.106, ZNode build bằng Go 1.27.3. Kèm theo đó:

- Listener không còn dùng MPTCP. Go bật MPTCP mặc định cho listener; v2node
  tắt nó vì lỗi bảo mật (Xray #7291). ZNode tắt ở hai lớp: `godebug
  multipathtcp=0` trong `go.mod` và `patches/xray-core/mptcp-default-off.patch`.
  Chỉ node đặt `tcpMptcp: true` trong sockopt mới bật lại.
- Vision đọc bộ đệm TLS theo kiểu thật của trường `rawInput`
  (`patches/xray-core/xtls-vision-go1273.patch`, Xray #7176). Nhờ vậy sau này
  nâng REALITY lên bản đồng bộ Go 1.27 thì VLESS Vision không bị crash.

Lõi Xray vẫn là fork wyx2685 v26.9.30, chưa lên v26.10.31 như v2node: 19 bản vá
riêng của ZNode chưa khớp bản mới. Hỗ trợ khoá X25519 lẻ của REALITY đã có sẵn
trong `patches/reality/02-legacy-x25519-compat.patch`.

## Freedom chọn IPv4 qua sockopt (theo v2node #54)

Lõi Xray đang dùng chỉ đọc `domainStrategy` của outbound Freedom từ
`streamSettings.sockopt`; trường `domainStrategy`/`targetStrategy` trong
`settings` bị bỏ qua. Trước v1.37.107, outbound mặc định khai `UseIPv4` ở
`settings` nên thực tế node vẫn có thể ra mạng bằng IPv6.

Từ v1.37.107:

- Outbound mặc định đặt `sockopt.domainStrategy: "UseIPv4"`, nên node ra mạng
  bằng IPv4 như ý định ban đầu.
- Outbound Freedom trong route của panel có `targetStrategy` hoặc
  `domainStrategy` ở `settings` được chuyển sang `sockopt`, trừ khi sockopt đã
  có giá trị riêng (`targetStrategy` được ưu tiên).

## RAM thật và giới hạn RAM khi VPS chạy chung phần mềm khác

Từ v1.37.108:

- Mục RAM của ZNode trên panel là RSS thật (`/proc/self/statm`), giống `top`
  và systemd. Trước đây panel nhận `MemStats.Sys` của Go, con số chỉ tăng chứ
  không giảm, nên node chạy lâu ngày hiện RAM cao dù đã trả bộ nhớ cho hệ thống.
- Mỗi phút ZNode tính lại giới hạn RAM cho Go theo phần RAM các chương trình khác
  để lại (RAM trống cộng RAM ZNode đang giữ): lấy 75% phần đó, không vượt giới
  hạn theo RAM/systemd như trước (50% RAM) và không dưới 128 MB. Ngưỡng trả bộ
  nhớ (85% giới hạn) đi theo. Trên VPS 1 GB chạy thêm phần mềm node khác, ZNode
  dọn bộ nhớ sớm hơn thay vì giữ tới gần 480 MB. Nếu đặt `GOMEMLIMIT` thì ZNode
  giữ nguyên giá trị đó.

## Khởi động lại nhanh khi cập nhật

Từ v1.37.109:

- Mỗi lần cập nhật hoặc khởi động lại, khách trên VPS mất kết nối cho tới khi
  ZNode mở lại cổng. Trước đây ZNode chờ panel trả manifest, thông tin node và
  danh sách user của mọi node rồi mới mở cổng, nên panel chậm (nhất là khi
  "cập nhật toàn bộ") làm khách mất mạng lâu.
- Nay ZNode chờ panel tối đa 5 giây. Nếu panel chưa trả lời mà có bản lưu cấu
  hình và user (đã ký, không quá 24 giờ) thì ZNode mở cổng ngay từ bản lưu, rồi
  đồng bộ với panel ngay sau đó. Panel không đổi gì thì Xray chạy tiếp, khách
  không bị ngắt lần nữa. Giới hạn thiết bị vẫn áp dụng.
- Không có bản lưu thì ZNode chờ panel như cũ. Panel lỗi hẳn thì vẫn chạy chế độ
  offline như trước.
- Nhật ký `Nodes started` có thêm `seconds`: thời gian từ lúc tiến trình chạy tới
  lúc mở cổng.
- Sau lỗi hoặc khi loadguard/memguard khởi động lại, systemd chạy lại ZNode sau
  5 giây thay vì 30 giây (`RestartSec=5`, áp dụng khi cài hoặc cập nhật).

## Bớt RAM cho mỗi kết nối

Từ v1.37.110:

- AnyTLS không mang chính sách bộ đệm của node, nên mỗi kết nối dùng bộ đệm
  mặc định của Xray: 512 KB mỗi chiều trên VPS amd64. Nay mọi giao thức đi qua
  pipe (Trojan, Shadowsocks, VMess, AnyTLS) dùng `BufferSize` của node (128 KB).
  VLESS, Hysteria2 và TUIC không dùng pipe nên không đổi.
- VPS nhỏ tự giảm bộ đệm đó: tới khoảng 1,25 GB RAM còn 32 KB, tới khoảng 3 GB
  còn 64 KB. Bộ đệm socket của kernel vẫn giữ tốc độ. v1.37.110 còn đặt
  `GOGC=50` ở hai mức này; từ v1.37.111 ZNode để mặc định của Go, vì VPS nhỏ
  (nhất là loại CPU burst) thường thiếu CPU hơn thiếu RAM, mà giới hạn RAM mềm
  đã tự bắt Go dọn rác mạnh hơn khi RAM gần hết.
- Hysteria2 giữ tối đa 2 MB upload chưa đọc mỗi luồng và 5 MB mỗi kết nối
  (trước là 8 MB và 20 MB). TUIC cũng vậy (trước tự tăng tới 6 MB và 15 MB) và
  nhận tối đa 1024 luồng mỗi kết nối. Ở 200 ms mỗi luồng vẫn tải lên khoảng
  80 Mbit/s; tải xuống không đổi. Trước đây người dùng bị giới hạn tốc độ mà tải
  lên nhiều (speedtest, sao lưu ảnh) làm một kết nối giữ tới 20 MB.
- Bản lưu cấu hình và user (dùng cho khởi động nhanh) chỉ ghi lại tối đa
  10 phút một lần khi chỉ có user thay đổi. Mỗi lần ghi phải đóng gói toàn bộ
  user của mọi node và ghi lại `config.json`, nên node đông user tạo hàng chục
  MB rác mỗi lần poll. Reload và thay đổi từ panel vẫn ghi ngay; khi tắt, ZNode
  ghi nốt phần còn chờ.
- User bị xoá không còn để lại một mục trong bộ điều phối tới lần khởi động lại.
- Tiến trình `znode-terminal` giới hạn RAM của Go ở 32 MB.

## Giới hạn bộ đệm của tuyến WireGuard

Từ bản sau v1.37.111:

- Tuyến WireGuard chạy kernel TUN dùng `wireguard-go`. Thư viện này cấp cho mỗi
  gói tin đang chờ, kể cả một gói ACK 60 byte, một bộ đệm 64 KB. Trên Linux nó
  không giới hạn số bộ đệm (Android giới hạn ở 4096, iOS ở 1024).
- Trên node HK 1 GB (05/11/2026), các bộ đệm này là phần lớn nhất của heap.
  Heap tăng lên sát giới hạn RAM của Go, khiến bộ dọn rác chiếm 1,5 nhân CPU
  và làm rớt gói UDP.
- Nay mỗi tuyến WireGuard chỉ giữ tối đa 1024 gói (64 MB). Mức 2048 và 4096
  gói chỉ còn khi người vận hành đặt `GOMEMLIMIT` trên 1,5 GB.
- Khi hết bộ đệm, tuyến chờ một bộ đệm được trả lại thay vì tạo thêm, nên TCP
  bên trong tự giảm tốc. Bản vá nằm ở `patches/wireguard/buffer-pool-limit.patch`.
- Memguard trả RAM rảnh cho hệ điều hành (`FreeOSMemory`) khi RAM của ZNode
  vượt ngưỡng. Nếu một lần trả gần như không thu được gì (dưới 16 MB), nó gấp
  đôi thời gian chờ tới lần sau, tối đa 30 phút. Trước đây node có heap đang
  dùng thật vẫn bị dọn rác toàn bộ mỗi phút mà không được lợi gì.
- Socket UDP của tuyến WireGuard trước đây đọc và ghi mỗi gói bằng một lời gọi
  hệ thống. Bên nhận đưa từng gói một vào TUN nên kernel không gộp (GRO) được
  các đoạn TCP. Trên Linux, socket nay đọc và ghi tối đa 64 gói mỗi lần
  (`recvmmsg`/`sendmmsg`). Cả lô gói nhận được vào TUN cùng lúc, và các gói từ
  cùng một địa chỉ peer dùng chung một endpoint thay vì cấp mới cho từng gói.
  Bản vá: `patches/xray-core/…-wireguard-bind-batch.patch`.
- Mỗi lần ghi dữ liệu xuống khách, bộ đếm lưu lượng phải kiểm tra phiên còn
  sống, bằng cách quét hết các kết nối của user đó. Nay mỗi phiên giữ con trỏ
  tới kết nối của nó nên kiểm tra ngay, không quét.
- Trên VPS có ngân sách RAM tới 1,5 GB (nay là mọi VPS, trừ khi đặt
  `GOMEMLIMIT` cao hơn), ZNode dùng GOGC 50 khi heap đang dùng thật từ 64 MB
  trở lên, và về mặc định 100 khi
  heap dưới 48 MB (memguard kiểm tra mỗi 15 giây). Người vận hành đặt GOGC thì
  ZNode không đổi. GOGC 50 bớt phần heap thừa (mặc định heap lên gấp đôi phần
  đang dùng rồi mới dọn), nhưng chỉ đáng khi heap lớn. Trên node 15.165
  (05/11/2026), GOGC 50 cố định với heap 25 MB làm Go dọn rác mỗi ~5 giây, tốn
  ~7% CPU của ZNode chỉ để bớt ~12 MB.
- Luồng UDP đi ra qua Freedom đóng sau 60 giây không có gói nào theo cả hai
  chiều (TCP vẫn theo `ConnIdle`, mặc định 300 giây, để giữ socket push của
  app). Trước đây mỗi truy vấn DNS hay phiên QUIC đã xong vẫn giữ socket, bộ đệm
  và khoảng 3 goroutine thêm 5 phút; trên node 15.165, một phần tư số goroutine
  là các luồng như vậy. Bản vá: `patches/xray-core/…-freedom-udp-idle.patch`.

## Sửa lấy từ v2node gốc (05/11/2026)

wyx2685/v2node v0.4.6, v0.4.7 và commit 9537998 không có cải tiến CPU/RAM
riêng. Go 1.27.3, tắt MPTCP, #53 và #54 đã có từ v1.37.106–v1.37.107. Phần còn
lại là bản Xray fork mới; ZNode chỉ lấy những sửa có ích cho server, trong
`patches/xray-core/…-upstream-2026-11-05-fixes.patch`:

- Xray #7327: đọc có hạn giờ trả lỗi hết giờ thay vì "không có gì". Trước đây
  outbound VMess/Trojan/SS và mux dùng để relay sau inbound VLESS gửi một khối
  rỗng đầu tiên; VMess coi đó là hết request, làm hỏng SSH, SMTP và các giao
  thức mà server nói trước.
- Xray #7091: dọn subscriber của DNS không cấp thừa bộ nhớ.
- Xray #7236: WebSocket đóng bình thường được coi là kết thúc, không ghi lỗi.
- "failed to resolve ip" ghi ở mức info thay vì error.

## Sniffing UDP/QUIC luôn bật

ZNode luôn đọc SNI của QUIC để chặn tên miền toàn cục và để rule tên miền
(kể cả rule đưa YouTube, Meta, TikTok vào WireGuard) khớp được với UDP. Từ
v1.37.114 không còn cách tắt: đã bỏ `disable_udp_content_sniffing` của panel và
`ConnectionConfig.DisableUDPContentSniffing` trong config. Config cũ còn khoá
này vẫn chạy, khoá bị bỏ qua; installer không ghi khoá này nữa. Panel đổi giá
trị cũ cũng không còn làm node reload. Đường hầm WireGuard không bị ảnh hưởng:
gói UDP gửi tới peer là kết nối đi ra, không qua bước sniffing.

## Bớt CPU: DNS và làm mới thiết bị (05/11/2026)

Đo trên VPS nhỏ (113 kết nối): tra DNS hệ thống chiếm khoảng 10% CPU của
ZNode, làm mới thiết bị sau mỗi lần ghi khoảng 2%.

- `patches/xray-core/…-local-dns-cache.patch`: trình phân giải hệ thống của Go
  không có cache, nên mỗi kết nối ra một tên miền đều mở socket UDP, hỏi A và
  AAAA rồi sắp xếp kết quả. Kết quả nay được giữ 30 giây (tối đa 4096 tên),
  lỗi không được giữ. REALITY cũng dùng cache này khi kết nối tới target ở mỗi
  lần bắt tay, ưu tiên IPv4, nên bắt tay nhanh hơn.
- Mỗi phiên làm mới lease thiết bị tối đa mỗi giây một lần thay vì mỗi lần ghi.
  Lease sống 60 giây, handover chờ 15 giây, nên giới hạn thiết bị vẫn chính xác.
  Lần làm mới bị từ chối không được nhớ: lần ghi kế tiếp hỏi lại ngay.

## WireGuard: tra DNS endpoint không treo quá hạn kết nối (Xray #7323)

Commit 05/11/2026 của v2node (9537998) chỉ nâng Xray fork lên 0061c59f. Các
sửa có ích cho server đã vào từ v1.37.112; sửa còn lại là #7323, được port tay
vào `patches/xray-core/…-wireguard-endpoint-lookup-deadline.patch` vì ZNode đã
vá các file WireGuard này. Khi dựng thiết bị WireGuard, việc tra DNS endpoint
dừng khi kết nối gây ra nó hết hạn, thay vì giữ khoá handler và chặn mọi kết
nối WireGuard khác. Socket mở lại khi phục hồi thì dừng khi handler đóng.

## Phát hành

GitHub Actions build binary theo kiến trúc khi push mã Go lên nhánh `main` hoặc
khi tạo Release. Để installer hoạt động, repository cần có ít nhất một GitHub
Release chứa các tệp `znode-linux-<arch>.zip` do workflow tạo ra.

## Cấu hình Redis

ZBoard và ZNode phải dùng cùng Redis nếu bật đồng bộ thiết bị thời gian thực.
Giữ cùng channel đã cấu hình trên panel, mặc định `v2board:device-sync`.

Thông tin Agent được lưu tại `/etc/znode/config.json` với quyền `0600`. Không
chia sẻ Agent token hoặc sao chép file này sang VPS khác.
Mọi cấu hình hợp lệ phải có trường `"type": "zboard"` ở cấp cao nhất.

Sau lần khởi động online thành công, ZNode ghi snapshot nguyên tử tại
`/var/lib/znode/runtime.snapshot`. File có quyền `0600`, được xác thực HMAC bằng
Agent token và chỉ được dùng khi API ZBoard không truy cập được. Snapshot không
có thời hạn tự hết hiệu lực để VPS tiếp tục phục vụ trong sự cố dài; khi panel
trở lại, các task tự đồng bộ cấu hình, user và traffic đang chờ. Chỉ phản hồi
thu hồi Agent có marker riêng từ ứng dụng ZBoard mới được phép gỡ các inbound;
trang lỗi `401/403` chung từ CDN/WAF không làm node dừng. Phía ZBoard chỉ gắn
marker này khi thật sự tìm thấy Agent bị vô hiệu/xóa hoặc token không khớp;
thiếu header, sai `type` panel hoặc runtime không hỗ trợ trả `401` không marker
để ZNode giữ cấu hình last-known-good và retry.

Traffic protocol 2 phân biệt `409 traffic_report_processing` (tiếp tục giữ và
retry cùng batch) với `409 traffic_report_payload_changed` (xung đột payload cần
operator kiểm tra). Khi một kết nối Hysteria kết thúc vì QUIC idle timeout,
ZNode ghi thêm IP khách, RTT, packet loss và byte counters để phân biệt mất
đường UDP thật với lỗi định tuyến WireGuard ở tầng sau.

## Giấy phép

Xem [LICENSE](LICENSE). Dự án sử dụng Xray core đã tùy chỉnh theo khai báo trong
`go.mod`.

## Dữ liệu GeoIP và GeoSite

Các rule Xray dùng `geoip:` và `geosite:` cần đồng thời hai file
`geoip.dat` và `geosite.dat`. Bản phát hành tự tải dữ liệu mới nhất từ
Loyalsoldier, trình cài đặt xác thực file không rỗng rồi đặt chúng tại
`/etc/znode`. Znode tự đặt `XRAY_LOCATION_ASSET` về thư mục chứa đủ hai file;
Docker image cũng đóng gói sẵn dữ liệu vào `/etc/znode`.

Khi chạy Docker, phải gắn volume bền vững vào `/var/lib/znode`, ví dụ
`-v znode-data:/var/lib/znode`. Đây là nơi lưu batch traffic chưa được ZBoard
xác nhận; không mount thư mục này sẽ làm mất batch đang chờ khi thay container.

Có thể đổi nguồn tải khi cài bằng biến `ZNODE_GEODATA_URL`, ví dụ một mirror
nội bộ có cấu trúc `.../geoip.dat` và `.../geosite.dat`.
